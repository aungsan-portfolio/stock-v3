"""
feature_pipeline.py -- ML Feature Engineering.
Transforms signals and market data into ML-ready feature vectors.
"""
from bisect import bisect_left
from collections import deque
from datetime import timedelta
import json
import logging
import os
from typing import Dict, List

import pandas as pd

import config
from strategies.base import TradeSignal

logger = logging.getLogger(__name__)

class FeaturePipeline:
    def __init__(self):
        self.feature_names = [
            "rr_ratio",
            "raw_confidence",
            "correlation_penalty",
            "max_correlation",
            "risk_per_share",
            "entry_stop_distance",
            "is_long"
        ]

    def build_features_from_signal(self, signal: TradeSignal, current_market_data: dict = None) -> Dict[str, float]:
        """Convert a single signal to a feature dict."""
        features = {}
        features["rr_ratio"] = float(getattr(signal, "reward_risk_ratio", 2.0))
        features["raw_confidence"] = float(signal.metadata.get("raw_confidence", signal.confidence))
        features["correlation_penalty"] = float(signal.metadata.get("correlation_penalty", 1.0))
        features["max_correlation"] = float(signal.metadata.get("max_correlation", 0.0))
        features["risk_per_share"] = float(getattr(signal, "risk_per_share", 0.0))
        features["entry_stop_distance"] = float(abs(signal.entry_price - signal.stop_price))
        features["is_long"] = 1.0 if signal.side.upper() == "BUY" else 0.0
        return features

    def build_features_from_df(self, df_signals: pd.DataFrame) -> pd.DataFrame:
        """Process exported signals CSV into feature dataframe."""
        df_features = pd.DataFrame()
        if "rr_ratio" in df_signals.columns:
            df_features["rr_ratio"] = pd.to_numeric(df_signals["rr_ratio"], errors='coerce').fillna(2.0)
        else:
            df_features["rr_ratio"] = 2.0

        if "raw_confidence" in df_signals.columns:
            df_features["raw_confidence"] = pd.to_numeric(df_signals["raw_confidence"], errors='coerce').fillna(0.5)
        else:
            df_features["raw_confidence"] = 0.5

        if "correlation_penalty" in df_signals.columns:
            df_features["correlation_penalty"] = pd.to_numeric(df_signals["correlation_penalty"], errors='coerce').fillna(1.0)
        else:
            df_features["correlation_penalty"] = 1.0

        if "max_correlation" in df_signals.columns:
            df_features["max_correlation"] = pd.to_numeric(df_signals["max_correlation"], errors='coerce').fillna(0.0)
        else:
            df_features["max_correlation"] = 0.0

        if "risk_per_share" in df_signals.columns:
            df_features["risk_per_share"] = pd.to_numeric(df_signals["risk_per_share"], errors='coerce').fillna(0.0)
        else:
            df_features["risk_per_share"] = 0.0

        if "entry_price" in df_signals.columns and "stop_price" in df_signals.columns:
            entry = pd.to_numeric(df_signals["entry_price"], errors='coerce')
            stop = pd.to_numeric(df_signals["stop_price"], errors='coerce')
            df_features["entry_stop_distance"] = (entry - stop).abs().fillna(0.0)
        else:
            df_features["entry_stop_distance"] = 0.0

        if "side" in df_signals.columns:
            df_features["is_long"] = (df_signals["side"].str.upper() == "BUY").astype(float)
        else:
            df_features["is_long"] = 1.0

        for f in self.feature_names:
            if f not in df_features.columns:
                df_features[f] = 0.0

        return df_features[self.feature_names]

    def compute_target(self, df_signals: pd.DataFrame, journal_path: str) -> pd.Series:
        """Return nullable win labels from explicit realized trade outcomes."""
        is_win = pd.Series(pd.NA, index=df_signals.index, dtype="Float64")
        try:
            if not os.path.exists(journal_path):
                return is_win

            max_rows = max(
                1,
                int(getattr(config, "DAYTRADE_ML_MAX_JOURNAL_ROWS", 100000)),
            )
            max_bytes = max(
                1024,
                int(getattr(config, "DAYTRADE_ML_MAX_JOURNAL_BYTES", 16 * 1024 * 1024)),
            )
            records = deque(maxlen=max_rows)
            with open(journal_path, "rb") as journal:
                file_size = journal.seek(0, os.SEEK_END)
                start_offset = max(0, file_size - max_bytes)
                journal.seek(start_offset)
                if start_offset:
                    journal.readline()

                for raw_line in journal:
                    try:
                        record = json.loads(raw_line.decode("utf-8"))
                    except (TypeError, UnicodeDecodeError, json.JSONDecodeError):
                        continue

                    event_type = record.get("event_type")
                    has_realized_pnl = (
                        record.get("realized_pnl") is not None
                        or record.get("pnl") is not None
                    )
                    is_closed = has_realized_pnl and (
                        event_type == "TRADE_CLOSED"
                        or (
                            event_type in {None, "TRADE"}
                            and (
                                record.get("exit_price") is not None
                                or record.get("exit_reason") is not None
                            )
                        )
                    )
                    if is_closed:
                        records.append(record)

            outcomes = pd.DataFrame(records)
            required_columns = {"symbol", "timestamp"}
            if outcomes.empty or not required_columns.issubset(outcomes.columns):
                return is_win

            outcomes["ts"] = pd.to_datetime(
                outcomes["timestamp"],
                utc=True,
                errors="coerce",
            )
            outcomes = outcomes.dropna(subset=["ts"]).sort_values("ts").reset_index(drop=True)
            outcomes["_outcome_id"] = outcomes.index
            grouped = {
                symbol: (
                    group["ts"].tolist(),
                    group.to_dict("records"),
                )
                for symbol, group in outcomes.groupby("symbol", sort=False)
            }
            outcomes_by_signal_id = {
                str(outcome["signal_id"]): outcome
                for outcome in outcomes.to_dict("records")
                if pd.notna(outcome.get("signal_id")) and outcome.get("signal_id")
            }
            if "timestamp" not in df_signals.columns:
                return is_win
            signal_times = pd.to_datetime(
                df_signals["timestamp"],
                utc=True,
                errors="coerce",
            )
            max_match_age = timedelta(
                hours=max(1, int(getattr(config, "DAYTRADE_ML_TARGET_MATCH_HOURS", 24)))
            )
            consumed_outcomes = set()

            for idx, signal in df_signals.iterrows():
                signal_id = signal.get("signal_id")
                if pd.notna(signal_id) and signal_id:
                    outcome = outcomes_by_signal_id.get(str(signal_id))
                    if outcome is not None:
                        pnl = outcome.get("realized_pnl")
                        if pd.isna(pnl):
                            pnl = outcome.get("pnl")
                        is_win.at[idx] = 1.0 if float(pnl) > 0 else 0.0
                        consumed_outcomes.add(outcome["_outcome_id"])
                        continue

                signal_time = signal_times.get(idx)
                symbol_group = grouped.get(signal.get("symbol"))
                if pd.isna(signal_time) or symbol_group is None:
                    continue

                timestamps, symbol_outcomes = symbol_group
                start = bisect_left(timestamps, signal_time)
                for outcome in symbol_outcomes[start:]:
                    if outcome["ts"] - signal_time > max_match_age:
                        break
                    outcome_id = outcome["_outcome_id"]
                    if outcome_id in consumed_outcomes:
                        continue
                    if not self._outcome_matches_signal(signal, outcome):
                        continue
                    pnl = outcome.get("realized_pnl")
                    if pd.isna(pnl):
                        pnl = outcome.get("pnl")
                    is_win.at[idx] = 1.0 if float(pnl) > 0 else 0.0
                    consumed_outcomes.add(outcome_id)
                    break
        except Exception as e:
            logger.warning(f"Target computation failed/mocked: {e}")

        return is_win

    @staticmethod
    def _outcome_matches_signal(signal: pd.Series, outcome: dict) -> bool:
        signal_id = signal.get("signal_id")
        outcome_signal_id = outcome.get("signal_id")
        has_signal_id = pd.notna(signal_id) and bool(signal_id)
        has_outcome_signal_id = pd.notna(outcome_signal_id) and bool(outcome_signal_id)
        if has_outcome_signal_id:
            return has_signal_id and str(signal_id) == str(outcome_signal_id)

        for field in ("side", "strategy"):
            signal_value = signal.get(field)
            outcome_value = outcome.get(field)
            if pd.isna(signal_value) or not outcome_value:
                return False
            if str(signal_value).upper() != str(outcome_value).upper():
                return False
        return True

    def get_feature_names(self) -> List[str]:
        return self.feature_names
