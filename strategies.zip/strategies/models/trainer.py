"""
trainer.py -- ML Model Training.
Trains RandomForest model on historical signal data.
"""
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict

import pandas as pd

import config
from strategies.models.feature_pipeline import FeaturePipeline
from strategies.trade_journal import backfill_closed_trades

logger = logging.getLogger(__name__)


def _chronological_split(X, y, timestamps, test_size):
    """Split labeled observations in timestamp order with the newest held out."""
    order = pd.to_datetime(timestamps, utc=True, errors="coerce").sort_values(
        kind="stable"
    ).index
    X_ordered = X.loc[order]
    y_ordered = y.loc[order]
    split_idx = int(len(X_ordered) * (1.0 - test_size))
    split_idx = min(max(split_idx, 1), len(X_ordered) - 1)
    return (
        X_ordered.iloc[:split_idx],
        X_ordered.iloc[split_idx:],
        y_ordered.iloc[:split_idx],
        y_ordered.iloc[split_idx:],
    )


class ModelTrainer:
    def __init__(self):
        self.pipeline = FeaturePipeline()
        self.model_path = Path(getattr(config, "DAYTRADE_ML_MODEL_PATH", "data/models/signal_predictor.pkl"))
        self.feature_importance_path = self.model_path.parent / "feature_importance.csv"
        self.metrics_path = self.model_path.parent / "model_metrics.json"

    def train(self, feature_csv_pattern: str = None) -> Dict[str, Any]:
        """Load data, train model, save artifacts."""
        try:
            backfill_closed_trades()
        except Exception as exc:
            logger.error(f"Failed to backfill ML target labels: {exc}")

        try:
            from sklearn.ensemble import RandomForestClassifier
            from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
            import joblib
        except ImportError:
            logger.error("scikit-learn is not installed. Cannot train ML model.")
            return {"error": "scikit-learn not installed"}

        if feature_csv_pattern is None:
            # Look for signals in exports (both CSV and JSONL)
            exports_dir = Path(config.DATA_DIR) / "exports"
            files = list(exports_dir.glob("signals_*.csv")) + list(exports_dir.glob("signals_*.jsonl"))
        else:
            from glob import glob
            files = [Path(p) for p in glob(feature_csv_pattern)]

        files = [path for path in files if path.is_file()]
        if feature_csv_pattern is None:
            cutoff = datetime.now() - timedelta(
                days=max(1, int(getattr(config, "EXPORT_KEEP_DAYS", 90)))
            )
            files = [
                path
                for path in files
                if datetime.fromtimestamp(path.stat().st_mtime) >= cutoff
            ]
        files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        files = files[:max(1, int(getattr(config, "DAYTRADE_ML_MAX_TRAINING_FILES", 90)))]

        if not files:
            logger.warning("No signal CSV files found for training.")
            return {"error": "no data"}

        dfs = []
        remaining_rows = max(
            1,
            int(getattr(config, "DAYTRADE_ML_MAX_TRAINING_ROWS", 100000)),
        )
        for f in files:
            if remaining_rows <= 0:
                break
            try:
                if f.suffix == '.csv':
                    frame = pd.read_csv(f, nrows=remaining_rows)
                elif f.suffix == '.jsonl':
                    frame = pd.read_json(f, lines=True, nrows=remaining_rows)
                else:
                    continue
                if not frame.empty:
                    dfs.append(frame)
                    remaining_rows -= len(frame)
            except Exception as e:
                logger.debug(f"Skipping unreadable file {f}: {e}")

        if not dfs:
            return {"error": "all data files empty"}

        df_signals = pd.concat(dfs, ignore_index=True)

        # Build features
        X = self.pipeline.build_features_from_df(df_signals)

        # Build targets
        journal_path = Path(getattr(config, "REPORTS_DIR", config.DATA_DIR / "reports")) / "trade_journal.jsonl"
        y = self.pipeline.compute_target(df_signals, str(journal_path))
        labeled = y.notna()
        X = X.loc[labeled]
        y = y.loc[labeled].astype(int)
        timestamps = df_signals.loc[labeled, "timestamp"]

        min_samples = getattr(config, "DAYTRADE_ML_MIN_TRAINING_SAMPLES", 50)
        if len(X) < min_samples:
            logger.warning(f"Not enough data to train. Found {len(X)}, required {min_samples}.")
            return {"error": f"insufficient data ({len(X)} < {min_samples})"}

        # Train/Test Split
        test_size = getattr(config, "DAYTRADE_ML_TEST_SIZE", 0.2)
        X_train, X_test, y_train, y_test = _chronological_split(
            X,
            y,
            timestamps,
            test_size,
        )

        # Train
        n_estimators = getattr(config, "DAYTRADE_ML_N_ESTIMATORS", 100)
        max_depth = getattr(config, "DAYTRADE_ML_MAX_DEPTH", 5)

        clf = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, random_state=42)
        clf.fit(X_train, y_train)

        # Evaluate
        y_pred = clf.predict(X_test)
        metrics = {
            "accuracy": float(accuracy_score(y_test, y_pred)),
            "precision": float(precision_score(y_test, y_pred, zero_division=0)),
            "recall": float(recall_score(y_test, y_pred, zero_division=0)),
            "f1": float(f1_score(y_test, y_pred, zero_division=0)),
            "samples": len(X)
        }

        # Save model
        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(clf, self.model_path)

        # Save Feature Importance
        fi = pd.DataFrame({
            "feature": self.pipeline.get_feature_names(),
            "importance": clf.feature_importances_
        }).sort_values(by="importance", ascending=False)
        fi.to_csv(self.feature_importance_path, index=False)

        # Save Metrics
        with open(self.metrics_path, "w") as f:
            json.dump(metrics, f, indent=2)

        logger.info(f"Model trained successfully. Accuracy: {metrics['accuracy']:.2f}")
        return metrics
