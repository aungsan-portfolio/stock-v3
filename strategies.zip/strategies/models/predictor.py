"""
predictor.py -- ML Model Inference.
Loads trained model and predicts win probability.
"""
import logging
import threading
import pandas as pd
from pathlib import Path
from typing import Dict, Optional

import config
from strategies.base import TradeSignal
from strategies.models.feature_pipeline import FeaturePipeline

logger = logging.getLogger(__name__)

_MODEL_CACHE = {}
_MODEL_CACHE_LOCK = threading.Lock()


class SignalPredictor:
    def __init__(self, model_path: str = None):
        self.model_path = Path(model_path or getattr(config, "DAYTRADE_ML_MODEL_PATH", "models/signal_predictor.pkl"))
        self.pipeline = FeaturePipeline()
        self.model = None
        self.ready = False
        self._load()

    def _load(self):
        try:
            import joblib
            if not self.model_path.exists():
                logger.debug(f"ML model not found at {self.model_path}")
                return

            cache_key = str(self.model_path.resolve())
            modified_ns = self.model_path.stat().st_mtime_ns
            with _MODEL_CACHE_LOCK:
                cached = _MODEL_CACHE.get(cache_key)
                if cached and cached[0] == modified_ns:
                    self.model = cached[1]
                else:
                    self.model = joblib.load(self.model_path)
                    _MODEL_CACHE[cache_key] = (modified_ns, self.model)
                    max_entries = max(
                        1,
                        int(getattr(config, "DAYTRADE_ML_MODEL_CACHE_MAX_ENTRIES", 4)),
                    )
                    while len(_MODEL_CACHE) > max_entries:
                        oldest_key = next(iter(_MODEL_CACHE))
                        if oldest_key == cache_key and len(_MODEL_CACHE) == 1:
                            break
                        _MODEL_CACHE.pop(oldest_key, None)

            self.ready = True
            logger.info(f"Loaded ML model from {self.model_path}")
        except ImportError:
            logger.warning("scikit-learn not installed. Predictor disabled.")
        except Exception as e:
            logger.error(f"Failed to load ML model: {e}")

    def predict(self, signal: TradeSignal, market_data: dict = None) -> Optional[float]:
        """Return win probability [0.0, 1.0]."""
        if not self.ready or self.model is None:
            return None

        try:
            features = self.pipeline.build_features_from_signal(signal, market_data)
            df = pd.DataFrame([features], columns=self.pipeline.get_feature_names())

            # predict_proba returns [[prob_0, prob_1]]
            proba = self.model.predict_proba(df)
            if proba.shape[1] > 1:
                return float(proba[0][1])
            else:
                # If model only knows one class
                return 1.0 if self.model.classes_[0] == 1 else 0.0
        except Exception as e:
            logger.error(f"Prediction failed for {signal.symbol}: {e}")
            return None

    def feature_importance(self) -> Dict[str, float]:
        """Read saved feature importance CSV."""
        fi_path = self.model_path.parent / "feature_importance.csv"
        if not fi_path.exists():
            return {}
        try:
            df = pd.read_csv(fi_path)
            return dict(zip(df["feature"], df["importance"]))
        except Exception:
            return {}
